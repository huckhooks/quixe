Edit = {};

Edit.DIR = /.*\//.exec(document.location)[0];
Edit.PROJECT_DIR = "";

Edit.PROJECT = "Hack_Hooks_Demo";

Edit.BUILDER = Edit.DIR + 'edit-i7-lib/edit_build_story.py';
Edit.XTERM = "/usr/bin/xterm";

//Edit.PLAYER = "edit-i7-lib/edit-play-full.html";
Edit.PLAYER = "edit-i7-lib/edit-play.html";
