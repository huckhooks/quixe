#!/bin/sh

#linux only
#save this script in your project folder (where the *.inform and *Materials is)

project=$PWD

# i prefer non-root installed 
mkdir -p ~/Inform/download-cli-inform
cd ~/Inform/download-cli-inform
wget -c http://inform7.com/download/content/6G60/I7_6G60_Linux_all.tar.gz
ls
tar -xzf I7_6G60_Linux_all.tar.gz
cd inform7-6G60
mkdir -p ~/Inform/cli-inform
./install-inform7.sh --prefix ~/Inform/cli-inform
ls ~/Inform

cd "$project"
ls


